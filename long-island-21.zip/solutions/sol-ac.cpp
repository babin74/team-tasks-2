#include <bits/stdc++.h>
#include <algorithm>

using namespace std;
using ll = long long;

struct Fenwick {
    int n;
    vector<int> fnw;

    Fenwick(int n) : n(n), fnw(n) {}

    void Add(int i, int x) {
        for (; i < n; i |= i + 1)
            fnw[i] += x;
    }

    int Query(int i) {
        int res = 0;
        for (; i >= 0; i = (i & (i + 1)) - 1)
            res += fnw[i];
        return res;
    }
};

struct Japan {
    int n, m;
    vector<vector<ll>> h;
    ll sea_level;

    struct HistoryItem {
        ll h;
        int dif;
    };

    vector<HistoryItem> history;
    vector<pair<int, ll>> queries;
    vector<ll> u;

    void AppendHistory(ll x, int dif) {
        u.push_back(x);
        history.push_back(HistoryItem{x, dif});
    }

    Japan(const vector<vector<ll>>& h)
        : n(h.size()), m(h[0].size()), h(h), sea_level(0) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                AppendHistory(h[i][j], +1);
                u.push_back(h[i][j]);

                if (i + 1 < n) {
                    AppendHistory(min(h[i][j], h[i + 1][j]), -1);
                }

                if (j + 1 < m) {
                    AppendHistory(min(h[i][j], h[i][j + 1]), -1);
                }

                if (i + 1 < n && j + 1 < m) {
                    AppendHistory(min({h[i][j], h[i + 1][j], h[i][j + 1],
                                       h[i + 1][j + 1]}),
                                  +1);
                }
            }
        }
    }

    void TrackAnswer() { queries.emplace_back((int)history.size(), sea_level); }

    void Set(int i, int j, ll x) {
        x += sea_level;
        if (h[i][j] == x)
            return;

        AppendHistory(h[i][j], -1);
        AppendHistory(x, 1);

// I'm so sorry for this code >~<
#define U(a)                                                \
    {                                                       \
        ll was = min(a, h[i][j]), now = min(a, x);          \
        if (was != now)                                     \
            AppendHistory(was, +1), AppendHistory(now, -1); \
    }
        if (i != 0)
            U(h[i - 1][j])
        if (i + 1 < n)
            U(h[i + 1][j])
        if (j != 0)
            U(h[i][j - 1])
        if (j + 1 < m)
            U(h[i][j + 1])
#undef U

// Sorry again :(
#define U(dx, dy)                                                    \
    {                                                                \
        ll y = min({h[i + dx][j], h[i][j + dy], h[i + dx][j + dy]}); \
        ll was = min(y, h[i][j]), now = min(y, x);                   \
        if (was != now)                                              \
            AppendHistory(was, -1), AppendHistory(now, +1);          \
    }
        if (i != 0 && j != 0)
            U(-1, -1)
        if (i != 0 && j + 1 < m)
            U(-1, +1)
        if (i + 1 < n && j != 0)
            U(+1, -1)
        if (i + 1 < n && j + 1 < m)
            U(+1, +1)
#undef U

        h[i][j] = x;
    }

    void AddSeaLevel(ll dx) { sea_level -= dx; }

    vector<int> GetAnswer() {
        const int q = queries.size();
        vector<int> ans(q);

        sort(u.begin(), u.end());
        u.erase(unique(u.begin(), u.end()), u.end());
        const int k = u.size();
        Fenwick fnw(k);

        for (int i = 0, j = 0; i < q; ++i) {
            for (; j < queries[i].first; ++j) {
                auto it = lower_bound(u.begin(), u.end(), history[j].h);
                fnw.Add(it - u.begin(), history[j].dif);
            }

            // queries[i].second is sea_level value after i-th day
            auto it = upper_bound(u.begin(), u.end(), queries[i].second);
            ans[i] = fnw.Query(k - 1) - fnw.Query(it - u.begin() - 1);
        }

        return ans;
    }
};

void solve() {
    int n, m, q;
    cin >> n >> m >> q;
    vector<vector<ll>> h(n, vector<ll>(m));
    for (auto& w : h)
        for (auto& x : w)
            cin >> x;
    Japan jp(h);

    for (int i = 0; i < q; ++i) {
        string op;
        cin >> op;
        if (op == "set") {
            int i, j, x;
            cin >> i >> j >> x;
            --i, --j;
            jp.Set(i, j, x);
        } else {
            int x;
            cin >> x;
            jp.AddSeaLevel(x);
        }
        jp.TrackAnswer();
    }

    auto ans = jp.GetAnswer();
    for (int x : ans)
        cout << x << '\n';
}

int main() {
    int t = 1;
    cin >> t;
    while (t--)
        solve();
}