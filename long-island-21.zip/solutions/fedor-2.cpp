#include "bits/stdc++.h"
#define rep(i, n) for(int i = 0; i < (n); ++i)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
#define ar array

using namespace std;
using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using pi = pair<int, int>;
using vpi = vector<pi>;
using vvi = vector<vi>;

const int INFi = 2e9;
const ll INF = 2e18;

struct fenwick {
    vector<ll> fenw;
    int n;

    void build(int sz) {
        n = sz;
        fenw.resize(n);
    }

    void upd(int i, ll c) {
        for(; i < n; i |= (i + 1)) fenw[i] += c;
    }

    ll get(int i) {
        ll r = 0;
        for(; i >= 0; i = (i & (i + 1)) - 1) r += fenw[i];
        return r;
    }
};

void solve() {
    int n, m, q; cin >> n >> m >> q;
    vector<vl> h(n, vl(m));
    rep(i, n) {
        rep(j, m) {
            cin >> h[i][j];
        }
    }
    ll A = 0;

    vector<ar<ll, 4>> que(q);

    vl xx = {0ll};

    for(auto &[tp, i, j, x] : que) {
        string s; cin >> s;
        if (s == "water") {
            tp = 1;
            cin >> x;
            A += x;

            xx.push_back(-A);
        } else {
            tp = 2;
            cin >> i >> j >> x;
            i--;
            j--;

            x -= A;
            xx.push_back(x);
        }
    }
    rep(i, n)
        rep(j, m) xx.push_back(h[i][j]);

    sort(all(xx));
    xx.resize(unique(all(xx)) - xx.begin());

    int sz = xx.size();

    vector<vector<ar<ll, 4>>> val(n, vector<ar<ll, 4>>(m, {INF, INF, INF, INF}));

    fenwick f;
    f.build(sz);

    auto calc = [&] (int i, int j, int mask) {
        if (i < 0 || j < 0) return;
        int dx = mask & 1;
        int dy = mask >> 1;
        if (i + dx >= n || j + dy >= m) return;

        ll res = INF;
        for(int x = i; x <= i + dx; ++x) {
            for(int y = j; y <= j + dy; ++y) {
                res = min(res, h[x][y]);
            }
        }

        if (val[i][j][mask] == res) return;

        int c = (dx == dy ? 1 : -1);
        if (val[i][j][mask] != INF) {
            int pos = lower_bound(all(xx), val[i][j][mask]) - xx.begin();
            f.upd(pos, c);
        } else {
            f.upd(0, c);
        }

        val[i][j][mask] = res;
        int pos = lower_bound(all(xx), val[i][j][mask]) - xx.begin();
        f.upd(pos, -c);
    };

    rep(i, n) rep(j, m) rep(t, 4) calc(i, j, t);

    auto Set = [&] (int i, int j, ll x) {
        h[i][j] = x;
        rep(t, 4) calc(i, j, t);
        calc(i - 1, j, 1);
        calc(i - 1, j, 3);
        calc(i, j - 1, 2);
        calc(i, j - 1, 3);
        calc(i - 1, j - 1, 3);
    };

    A = 0;

    for(auto &[tp, i, j, x] : que) {
        if (tp == 1) {
            A += x;
        } else {
            Set(i, j, x);
        }

        int pos = lower_bound(all(xx), -A) - xx.begin();
        cout << f.get(pos) << '\n';
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout << setprecision(10) << fixed;
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
}