#include <bits/stdc++.h>

using namespace std;
using vi = vector<int>;
using ll = long long;

const int N = 1000, M = 1000;
int n, m, used[N][M], utimer;
ll x[N][N];

void dfs(int i, int j) {
    if (i < 0 || j < 0 || i >= n || j >= m)
        return;
    if (x[i][j] <= 0 || used[i][j] == utimer)
        return;

    used[i][j] = utimer;
    dfs(i - 1, j);
    dfs(i + 1, j);
    dfs(i, j - 1);
    dfs(i, j + 1);
}

void solve() {
    int q;
    cin >> n >> m >> q;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j)
            cin >> x[i][j];
    }

    while (q--) {
        string op;
        cin >> op;
        if (op == "water") {
            ll dx;
            cin >> dx;
            for (int i = n; i--;)
                for (int j = m; j--;)
                    x[i][j] += dx;
        } else {
            int i, j, y;
            cin >> i >> j >> y;
            --i, --j;
            x[i][j] = y;
        }

        ++utimer;
        int ans = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (x[i][j] <= 0 || used[i][j] == utimer)
                    continue;
                ++ans;
                dfs(i, j);
            }
        }
        cout << ans << '\n';
    }
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--)
        solve();
}