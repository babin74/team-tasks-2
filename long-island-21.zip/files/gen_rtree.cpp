#include <bits/stdc++.h>
#include "cli_args.hpp"
#include "testlib.h"

using namespace std;
using ll = long long;
using pi = pair<int, int>;
CLIArguments args;

constexpr int N = 1000;
constexpr int C = 500'000'000;
constexpr int V = N * N;

int n, m, q, par[V], tl[V], tr[V];
vector<int> go[V], sons[V], start;

int GetVertexId(int i, int j) {
    return i * m + j;
}

pi GetPosition(int v) {
    return {v / m, v % m};
}

void BuildGraph() {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            const int v = GetVertexId(i, j);
            if (i + 1 < n) {
                const int u = GetVertexId(i + 1, j);
                go[v].push_back(u);
                go[u].push_back(v);
            }
            if (j + 1 < m) {
                const int u = GetVertexId(i, j + 1);
                go[v].push_back(u);
                go[u].push_back(v);
            }
        }
    }
}

void BuildRandomTree() {
    const int vc = n * m;
    vector<char> used(vc);
    auto x_ord = rnd.perm(vc);
    fill(par, par + vc, -1);

    priority_queue<pi> q;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (i != 0 && i != n - 1 && j != 0 && j != m - 1)
                continue;
            const int v = GetVertexId(i, j);
            q.emplace(x_ord[v], v);
            used[v] = 1;
            start.push_back(v);
        }
    }

    while (!q.empty()) {
        int v = q.top().second;
        q.pop();
        for (int to : go[v]) {
            if (used[to])
                continue;
            sons[v].push_back(to);
            par[to] = v;
            q.emplace(x_ord[to], to);
            used[to] = 1;
        }
    }
}

struct SegmentTreeMin {
    int n;
    vector<pi> t;

    SegmentTreeMin(int n) : n(n), t(2 * n) {}

    void Set(int i, int x) {
        for (t[i += n] = {x, i}; i != 0; i >>= 1)
            t[i >> 1] = min(t[i], t[i ^ 1]);
    }

    pi Query(int l, int r) {
        pi res = t[n + l];
        for (l += n, r += n - 1; l <= r; l >>= 1, r >>= 1) {
            if ((l & 1) == 1)
                res = min(res, t[l++]);
            if ((r & 1) == 0)
                res = min(res, t[r--]);
        }
        return res;
    }

    void Swap(int i, int j) {
        if (i != j) {
            const int x = t[i + n].first;
            const int y = t[j + n].first;
            Set(i, y);
            Set(j, x);
        }
    }
};

int DfsEuler(int v, int gt) {
    tl[v] = gt++;
    for (int to : sons[v])
        gt = DfsEuler(to, gt);
    tr[v] = gt;
    return gt;
}

void DfsFix(int v, SegmentTreeMin& sgt) {
    int pos = sgt.Query(tl[v], tr[v]).second;
    sgt.Swap(pos, tl[v]);

    for (int to : sons[v])
        DfsFix(to, sgt);
}

vector<int> GenRandomHeights() {
    const int vc = n * m;
    vector<int> p = rnd.perm(vc);

    SegmentTreeMin sgt(vc);
    for (int i = 0; i < vc; ++i)
        sgt.Set(i, p[i]);

    int gt = 0;
    for (int v : start)
        gt = DfsEuler(v, gt);
    for (int v : start)
        DfsFix(v, sgt);

    vector<int> y(vc);
    for (int i = 0; i < vc; ++i)
        y[i] = sgt.t[vc + tl[i]].first;
    return y;
}

int main(int argc, char** argv) {
    ios::sync_with_stdio(0), cin.tie(0);
    registerGen(argc, argv, 1);
    args.Parse(argc, argv);

    n = args.GetInt("n");
    m = args.GetInt("m");
    q = args.GetInt("q");
    int change_percent = args.GetInt("p");
    ensure(0 <= change_percent && change_percent <= 100);

    BuildGraph();
    BuildRandomTree();

    const int vc = n * m;
    vector<int> block_values(2 * vc);
    for (int& x : block_values)
        x = rnd.next(0, C);
    sort(block_values.begin(), block_values.end());
    for (int i = 0; i < 2 * vc; ++i)
        block_values[i] += i;
    shuffle(block_values.begin(), block_values.end());
    sort(block_values.begin(), block_values.begin() + vc);
    sort(block_values.begin() + vc, block_values.end());

    auto y1 = GenRandomHeights();
    for (int& x : y1)
        x = block_values[x];

    auto y2 = GenRandomHeights();
    for (int& x : y2)
        x = block_values[x + vc];

    vector<int> change_order, kurwa = y1;
    vector<int> not_changed(vc);
    iota(not_changed.begin(), not_changed.end(), 0);

    int ops = 0;
    while (!not_changed.empty()) {
        ++ops;

        int pos = rnd.next(0, (int)not_changed.size() - 1);
        swap(not_changed[pos], not_changed.back());
        const int v = not_changed.back();

        bool ok = par[v] == -1 || kurwa[par[v]] < y2[v];
        for (int to : sons[v]) {
            if (kurwa[to] <= y2[v]) {
                ok = false;
                break;
            }
        }
        if (ok) {
            change_order.push_back(v);
            kurwa[v] = y2[v];
            not_changed.pop_back();
        }
    }

    cerr << "ops = " << ops << endl;

    const int set_cnt = min(q, change_percent * q / 100);

    vector<ll> osps(vc + 1);
    for (int i = 0; i < vc; ++i) {
        const int v = change_order[i];
        osps[i + 1] = osps[i] + abs(y1[v] - y2[v]);
    }

    int start_set = 0;
    for (int i = 0; i + set_cnt <= vc; ++i) {
        if (osps[start_set + set_cnt] - osps[start_set] <
            osps[i + set_cnt] - osps[i])
            start_set = i;
    }

    for (int i = 0; i < start_set; ++i) {
        const int v = change_order[i];
        y1[v] = y2[v];
    }

    println(1);
    println(n, m, q);
    for (int i = 0; i < n; ++i) {
        vector<int> row(m);
        for (int j = 0; j < m; ++j)
            row[j] = y1[GetVertexId(i, j)];
        println(row);
    }

    vector<int> qtype(q);
    fill(qtype.begin(), qtype.begin() + set_cnt, 1);
    shuffle(qtype.begin(), qtype.end());

    int sea_level = 0;
    for (int i = 0; i < q; ++i) {
        if (qtype[i]) {
            const int v = change_order[start_set++];
            auto [i, j] = GetPosition(v);
            println("set", i + 1, j + 1, y2[v] - sea_level);
        } else {
            int new_sea_level = rnd.next(0, C);
            println("water", sea_level - new_sea_level);
            sea_level = new_sea_level;
        }
    }
}