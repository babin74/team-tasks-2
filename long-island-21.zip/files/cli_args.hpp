#pragma once

#include <string>
#include <unordered_map>

struct CLIArguments {
    std::string program_name;
    std::unordered_map<std::string, std::string> args;

    inline void Parse(int argc, char* argv[]) {
        program_name = argv[0];
        for (int i = 1; i != argc; ++i) {
            const std::string arg = argv[i];
            auto equal_pos = arg.find('=');
            if (equal_pos != std::string::npos) {
                const std::string key = arg.substr(0u, equal_pos);
                const std::string value = arg.substr(equal_pos+1u);
                args[key] = value;
            }
        }
    }

    long long GetInt(const std::string& key) {
        const std::string& value = args[key];
        size_t exp_pos = value.find('e');
        if (exp_pos != std::string::npos) {
            long long res = stoll(value.substr(0u, exp_pos));
            long long exp = stoll(value.substr(exp_pos+1));
            while (exp != 0) res *= 10, --exp;
            return res;
        }
        return stoll(args[key]);
    }

    std::string GetStr(const std::string& key) {
        return args[key];
    }
};