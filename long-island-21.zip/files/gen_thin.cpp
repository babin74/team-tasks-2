#include <bits/stdc++.h>
#include "cli_args.hpp"
#include "testlib.h"

using namespace std;
using pi = pair<int, int>;
using ll = long long;
CLIArguments args;

constexpr int C = 500'000'000;

struct Dsu {
    vector<int> p, c;
    Dsu(int n) : p(n), c(n, 1) { iota(p.begin(), p.end(), 0); }

    int Root(int v) { return v == p[v] ? v : p[v] = Root(p[v]); }

    bool Unite(int a, int b) {
        a = Root(a), b = Root(b);
        if (a == b) {
            return false;
        } else {
            if (c[a] < c[b])
                swap(a, b);
            p[b] = a;
            c[a] += c[b];
            return true;
        }
    }
};

int main(int argc, char** argv) {
    ios::sync_with_stdio(0), cin.tie(0);
    registerGen(argc, argv, 1);
    args.Parse(argc, argv);

    const int n = args.GetInt("n");
    const int m = args.GetInt("m");
    const int q = args.GetInt("q");

    const int nb = (n + 1) / 3, mb = (m + 1) / 3;
    vector<pi> vset;
    for (int i = 0; i < nb; ++i) {
        for (int j = 0; j < mb; ++j) {
            vset.emplace_back(3 * i + 0, 3 * j + 0);
            vset.emplace_back(3 * i + 0, 3 * j + 1);
            vset.emplace_back(3 * i + 1, 3 * j + 0);
            vset.emplace_back(3 * i + 1, 3 * j + 1);
        }
    }

    vector<pi> edges;
    for (int i = 0; i < nb; ++i) {
        for (int j = 0; j < mb; ++j) {
            if (j + 1 < mb) {
                edges.emplace_back(i * mb + j, i * mb + (j + 1));
                // vset.emplace_back(3 * i + (i + j) % 2, 3 * j + 2);
            }
            if (i + 1 < nb) {
                edges.emplace_back(i * mb + j, (i + 1) * mb + j);
                // vset.emplace_back(3 * i + 2, 3 * j + 1 - (i + j) % 2);
            }
        }
    }
    shuffle(edges.begin(), edges.end());
    Dsu dsu(nb * mb);
    for (auto [u, v] : edges) {
        if (!dsu.Unite(u, v))
            continue;
        const int i = u / mb, j = u % mb;
        if (v == u + 1) {
            vset.emplace_back(3 * i + (i + j) % 2, 3 * j + 2);
        } else {
            vset.emplace_back(3 * i + 2, 3 * j + 1 - (i + j) % 2);
        }
    }

    vector<string> v(n, string(m, '.'));
    for (auto [x, y] : vset)
        v[x][y] = '+';

    int max_dist = 0;
    vector<vector<int>> dist(n, vector<int>(m));
    queue<pi> que;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (v[i][j] == '+')
                continue;

            if (i == 0 || j == 0 || i + 1 == n || j + 1 == m) {
                que.emplace(i, j);
            } else {
                dist[i][j] = -1;
            }
        }
    }

    while (!que.empty()) {
        auto [i, j] = que.front();
        max_dist = dist[i][j];
        que.pop();
        static vector<pi> neigh{pi{-1, 0}, {1, 0}, {0, 1}, {0, -1}};
        for (auto [di, dj] : neigh) {
            const int xi = i + di, xj = j + dj;
            if (0 <= xi && xi < n && 0 <= xj && xj < m) {
                if (dist[xi][xj] != -1 || v[xi][xj] == '+')
                    continue;
                dist[xi][xj] = dist[i][j] + 1;
                que.emplace(xi, xj);
            }
        }
    }

    for (auto [x, y] : vset) {
        dist[x][y] = rnd.next(max_dist + 1, C);
    }

    println(1);
    println(n, m, q);
    for (auto& w : dist)
        println(w);

    int sea_level = 0;
    for (int i = 0; i < q; ++i) {
        int type = rnd.next(1, 2);
        if (type == 1) {
            int new_sea_level = rnd.next(0, C);
            println("water", sea_level - new_sea_level);
            sea_level = new_sea_level;
        } else {
            auto [i, j] = rnd.any(vset);
            int nxt = rnd.next(max_dist+1, C);
            println("set", i+1, j+1, nxt - sea_level);
            ensure(dist[i][j] > max_dist);
            dist[i][j] = nxt;
        }
    }
}