#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;
using ll = long long;
using pi = pair<int, int>;

constexpr int T = 100;
constexpr int N = 1000;
constexpr int Q = 100'000;
constexpr int S = 300'000;
constexpr int C = 1'000'000'000;

int main(int argc, char** argv) {
    ios::sync_with_stdio(0);
    cin.tie(0);
    registerValidation(argc, argv);

    const int t = inf.readInt(1, T, "t");
    inf.readEoln();

    const array<pi, 4> neigh{{pi{-1, 0}, pi{1, 0}, pi{0, 1}, pi{0, -1}}};

    long long sum_nm = 0, sum_q = 0;
    for (int testid = 1; testid <= t; ++testid) {
        setTestCase(testid);

        const int n = inf.readInt(1, N, "n");
        inf.readSpace();
        const int m = inf.readInt(1, N, "m");
        inf.readSpace();
        const int q = inf.readInt(1, Q, "q");
        inf.readEoln();

        sum_nm += n * m;
        ensuref(sum_nm <= S, "sum(nm) is too big");
        sum_q += q;
        ensuref(sum_q <= Q, "sum(q) is too big");

        vector<vector<ll>> h(n);
        for (int row = 0; row < n; ++row) {
            h[row] =
                inf.readLongs(m, -(ll)C, +(ll)C, "h_" + to_string(row + 1));
            inf.readEoln();
        }
        vector<vector<int>> cnt_greater(n, vector<int>(m));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < m; ++j) {
                for (auto [di, dj] : neigh) {
                    const int ai = i + di, aj = j + dj;
                    if (0 <= ai && ai < n && 0 <= aj && aj < m) {
                        if (h[i][j] > h[ai][aj])
                            ++cnt_greater[i][j];
                    }
                }

                if (i == 0 || j == 0 || i + 1 == n || j + 1 == m) {
                    cnt_greater[i][j] += 228;
                }
                ensuref(cnt_greater[i][j] > 0,
                        "`condition` (3) is false");
            }
        }

        ll sea_level = 0;
        for (int op_id = 0; op_id < q; ++op_id) {
            string op = inf.readToken("set|water", "type");
            if (op == "set") {
                inf.readSpace();
                int i = inf.readInt(1, n, "i") - 1;
                inf.readSpace();
                int j = inf.readInt(1, m, "j") - 1;
                inf.readSpace();
                int x = inf.readInt(-C, +C, "x");
                inf.readEoln();

                x += sea_level;

                for (auto [di, dj] : neigh) {
                    const int ai = i + di, aj = j + dj;
                    if (0 <= ai && ai < n && 0 <= aj && aj < m) {
                        if (h[i][j] > h[ai][aj])
                            --cnt_greater[i][j];
                        if (x > h[ai][aj])
                            ++cnt_greater[i][j];
                        if (h[i][j] < h[ai][aj])
                            --cnt_greater[ai][aj];
                        if (x < h[ai][aj])
                            ++cnt_greater[ai][aj];
                    }
                }
                h[i][j] = x;
                for (auto [di, dj] : neigh) {
                    const int ai = i + di, aj = j + dj;
                    if (0 <= ai && ai < n && 0 <= aj && aj < m) {
                        ensuref(cnt_greater[ai][aj] > 0,
                                "`condition` (1) is false");
                    }
                }
                ensuref(cnt_greater[i][j] > 0,
                        "`condition` (2) is false, id=%d", op_id);

            } else {
                ensure(op == "water");

                inf.readSpace();
                int x = inf.readInt(-C, +C, "x");
                inf.readEoln();

                sea_level -= x;
            }
        }
    }

    inf.readEof();
}