#include <bits/stdc++.h>
#include <cctype>
#include <memory>
#include "testlib.h"

#define x first
#define y second

using namespace std;
using pi = pair<int, int>;
using vi = vector<int>;

constexpr int Q = 40;
constexpr int N = 1'000'000'000;

struct Interactor {
    int n, m;

    map<pi, int> known;

    Interactor(int n, int m) : n(n), m(m) {
        if (n < 2 || m < 2) {
            quitf(_fail, "Wrong n, m");
        }
    }

    void Init() {
        auto a = StartCells();
        for (int i = 0; i < 3; i++) {
            known[a[i]] = i + 1;
            if (!CheckCell(a[i])) {
                quitf(_fail, "wrong first cell");
            }
            if (col(a[i].x, a[i].y) != i + 1) {
                quitf(_fail, "wrong first cell color");
            }
        }
    }

    pair<int, int> GetSize() {
        return {n, m};
    }

    virtual ~Interactor() = default;

    virtual int col(int x, int y) = 0;

    virtual array<pi, 3> StartCells() = 0;

    bool CheckCell(int x, int y) {
        return 0 <= x && x < n && 0 <= y && y < m;
    }

    bool CheckCell(pi pt) { return CheckCell(pt.first, pt.second); }

    virtual int Ask(int x, int y) {
        if (!CheckCell(x, y)) {
            quitf(_wa, "Wrong cell asked: %d, %d", x, y);
        }
        int a = col(x, y);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (abs(dx) + abs(dy) != 1) {
                    continue;
                }
                auto itx = known.find(pi{x + dx, y + dy});
                if (itx == known.end()) {
                    continue;
                }
                if (itx->second == a) {
                    quitf(_fail, "Bad neighbours");
                }
            }
        }
        known[{x, y}] = a;
        return a;
    }

    bool finish() {
        bool found = false;
        for (int dx = -1; dx <= 1; ++dx) {
            for (int dy = -1; dy <= 1; ++dy) {
                if (dx * dy == 0 || found) {
                    continue;
                }
                for (auto [cell, col0] : known) {
                    auto [cx, cy] = cell;
                    auto itx = known.find(pi{cx + dx, cy});
                    if (itx == known.end()) {
                        continue;
                    }
                    auto colx = itx->second;
                    if (colx == col0) {
                        quitf(_fail, "Cells same color");
                    }
                    auto ity = known.find(pi{cx, cy + dy});
                    if (ity == known.end()) {
                        continue;
                    }
                    auto coly = ity->second;
                    if (coly == col0) {
                        quitf(_fail, "Cells same color");
                    }
                    if (col0 != colx && col0 != coly && colx != coly) {
                        found = true;
                    }
                }
            }
        }
        return found;
    }
};

struct InteractorManual : public Interactor {
    vector<vi> a;
    array<pi, 3> s;

    InteractorManual(int n, int m, const vector<vi>& a, array<pi, 3> s)
        : Interactor(n, m), a(a), s(s) {}

    array<pi, 3> StartCells() { 
        return s; 
    }
    int col(int x, int y) {
        return a[x][y];
    }
};

struct InteractorRandom : public Interactor {
    int zeta;
    int bound;
    bool revx;
    vector<int> perm;
    array<pi, 3> start;

    InteractorRandom(int n, int m) : Interactor(n, m) {
        zeta = rnd.next(0, 1);
        bound = rnd.next(zeta, n + m - 4);
        perm = rnd.perm(3, 1);
        revx = rnd.next(0, 1);

        for (int i = 0; i < 3; ++i) {
            while (true) {
                int lx = 0;
                int rx = n - 1;
                int ly = 0;
                int ry = m - 1;
                if (i == 0) {
                    rx = min(rx, bound + 228);
                    ry = min(ry, bound + 228);
                }
                if (i == 1) {
                    lx = max(lx, n - (n + m - bound + 228));
                    ly = max(ly, m - (n + m - bound + 228));
                }

                start[i].x = rnd.next(lx, rx);
                start[i].y = rnd.next(ly, ry);
                if (revx) {
                    start[i].x = n - 1 - start[i].x;
                }
                int c = col(start[i].x, start[i].y);
                if (c == perm[i]) {
                    break;
                }
            }
        }
        sort(start.begin(), start.end(), [this](pi a, pi b) {
            return col(a.x, a.y) < col(b.x, b.y);
        });
    }

    int col(int x, int y) {
        if (revx) {
            x = n - 1 - x;
        }
        if ((x + y) % 2 == zeta) {
            return (x + y <= bound) ? perm[0] : perm[1];
        } else {
            return perm[2];
        }
    }

    array<pi, 3> StartCells() {
        return start;
    }
};

struct Interactor123 : public Interactor {
    array<pi, 3> start;
    bool sign;
    vector<int> perm;

    Interactor123(int n, int m) : Interactor(n, m) {
        perm = rnd.perm(3, 1);
        sign = rnd.next(0, 1);
        for (int i = 0; i < 3; ++i) {
            while (true) {
                start[i].x = rnd.next(0, n - 1);
                start[i].y = rnd.next(0, m - 1);
                int c = col(start[i].x, start[i].y);
                if (c == i + 1) {
                    break;
                }
            }
        }
    }

    int col(int x, int y) {
        int t = n + m + x;
        if (sign) {
            t += y;
        } else {
            t -= y;
        }
        return perm[t % 3];
    }

    array<pi, 3> StartCells() {
        return start;
    }
};

struct InteractorSingle : public Interactor {
    array<pi, 3> start;
    pi fix;
    vector<int> perm;

    InteractorSingle(int n, int m) : Interactor(n, m) {
        perm = rnd.perm(3, 1);
        fix = {rnd.next(0, n - 1), rnd.next(0, m - 1)};
        for (int i = 0; i < 2; ++i) {
            while (true) {
                start[i].x = rnd.next(0, n - 1);
                start[i].y = rnd.next(0, m - 1);
                int c = col(start[i].x, start[i].y);
                if (c == perm[i]) {
                    break;
                }
            }
        }
        start[2] = fix;
        sort(start.begin(), start.end(), [this](pi a, pi b) {
            return col(a.x, a.y) < col(b.x, b.y);
        });
    }

    int col(int x, int y) {
        if (x == fix.x && y == fix.y) {
            return perm[2];
        } else {
            return perm[(x + y) % 2];
        }
    }

    array<pi, 3> StartCells() {
        return start;
    }
};

std::unique_ptr<Interactor> ReadInteractor(string type, int n, int m) {
    if (type == "manual") {
        array<pi, 3> s;
        for (auto& [x, y] : s) {
            x = inf.readInt(1, n, "x");
            y = inf.readInt(1, m, "x");
            x--;
            y--;
        }

        vector<vector<int>> a(n);
        for (auto& w : a)
            w = inf.readInts(m, 1, 3);
        return make_unique<InteractorManual>(n, m, a, s);
    } else if (type == "random") {
        return make_unique<InteractorRandom>(n, m);
    } else if (type == "123") {
        return make_unique<Interactor123>(n, m);
    } else if (type == "single") {
        return make_unique<InteractorSingle>(n, m);
    }

    assert(false);
}

void RunTestCase(std::unique_ptr<Interactor>& inter) {
    inter->Init();

    auto [n, m] = inter->GetSize();

    auto [c1, c2, c3] = inter->StartCells();

    // Print init information
    cout.flush();
    cout << n << " " << m;
    cout << " " << c1.x + 1 << " " << c1.y + 1;
    cout << " " << c2.x + 1 << " " << c2.y + 1;
    cout << " " << c3.x + 1 << " " << c3.y + 1 << endl;

    for (int i = 0; i <= Q; ++i) {
        string op = ouf.readToken("[a-zA-Z]+");
        for (char& ch : op) { 
            ch = tolower(ch);
        }

        if (op == "ask") {
            if (i >= Q) {
                tout << "too many questions" << endl;
                quitf(_wa, "too many questions");
            }

            int x = ouf.readInt(1, n);
            int y = ouf.readInt(1, m);
            x--; y--;
            cout << inter->Ask(x, y) << endl;
        } else if (op == "done") {
            if (!inter->finish()) {
                quitf(_wa, "No triangle found");
            }

            break;
        } else {
            tout << "unknown operation" << endl;
            quitf(_wa, "unknown operation");
        }
    }

    tout << "ok" << endl;
}

int main(int argc, char** argv) {
    registerInteraction(argc, argv);
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t = inf.readInt();
    auto inter = inf.readToken();

    int n = inf.readInt();
    int m = inf.readInt();
    
    cout << t << endl;
    for (int i = 0; i < t; ++i) {
        setTestCase(i + 1);
        auto inte = ReadInteractor(inter, n, m);
        RunTestCase(inte);
    }
    quitf(_ok, "OK");
}