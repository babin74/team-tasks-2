//#pragma GCC optimize("Ofast")
//#pragma GCC target("avx,avx2,fma")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4.1,sse4.2,sse4a,avx,avx2,popcnt,tune=native")
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <random>
#include <bitset>
#include <array>
#include <climits>
using namespace std;

#ifdef LOCAL
	#define eprintf(...) {fprintf(stderr, __VA_ARGS__);fflush(stderr);}
#else
	#define eprintf(...) 42
#endif

using ll = long long;
using ld = long double;
using uint = unsigned int;
using ull = unsigned long long;
using pii = pair<int, int>;
using pli = pair<ll, int>;
using pll = pair<ll, ll>;
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
ll myRand(ll B) {
	return (ull)rng() % B;
}

#define mp make_pair
#define all(x) (x).begin(),(x).end()

clock_t startTime;
double getCurrentTime() {
	return (double)(clock() - startTime) / CLOCKS_PER_SEC;
}

ll floor_div(ll x, ll y) {
	assert(y != 0);
	if (y < 0) {
		y = -y;
		x = -x;
	}
	if (x >= 0) return x / y;
	return (x + 1) / y - 1;
}
ll ceil_div(ll x, ll y) {
	assert(y != 0);
	if (y < 0) {
		y = -y;
		x = -x;
	}
	if (x <= 0) return x / y;
	return (x - 1) / y + 1;
}
template<typename T>
T sqr(T x) {
	return x * x;
}

int query(int x, int y) {
	cout << "ask " << x << " " << y << endl;
	cin >> x;
	return x;
}

void solve() {
	int n, m, x1, x2, x3, y1, y2, y3, c1, c2;
	cin >> n >> m >> x1 >> y1 >> x2 >> y2 >> x3 >> y3;
	if ((abs(x1 - x2) + abs(y1 - y2)) % 2 == 0) {
		c1 = 1;
		c2 = 2;
	} else if ((abs(x1 - x3) + abs(y1 - y3)) % 2 == 0) {
		x2 = x3;
		y2 = y3;
		c1 = 1;
		c2 = 3;
	} else {
		x1 = x3;
		y1 = y3;
		c1 = 3;
		c2 = 2;
	}
	if (x1 != x2 && y1 != y2) {
		if (abs(x2 - x1) % 2 == 0) {
			int c = query(x1, y2);
			if (c != c1) {
				c2 = c;
				x2 = x1;
			} else {
				y1 = y2;
			}
		} else {
			int x = x2 - 1, y = y1;
			if (x1 > x2) x = x2 + 1;
			int c = query(x, y);
			if (c != c1) {
				x2 = x;
				y2 = y;
				c2 = c;
			} else {
				x1 = x;
				y1 = y;

				x = x2;
				y = y1 - 1;
				if (y2 > y1) y = y1 + 1;
				c = query(x, y);
				if (c != c2) {
					x2 = x;
					y2 = y;
					c2 = c;
				} else {
					x2 = x;
					y2 = y;
					query(x1, y2);
					cout << "done" << endl;
					return;
				}
			}
		}
	}
	if (x1 + y1 > x2 + y2) {
		swap(x1, x2);
		swap(y1, y2);
		swap(c1, c2);
	}
	while(x2 + y2 - x1 - y1 > 2) {
		int x = x1, y = y1;
		if (x1 != x2) {
			x += ((x2 - x1) / 4) * 2;
		} else {
			y += ((y2 - y1) / 4) * 2;
		}
		int c = query(x, y);
		if (c != c1) {
			x2 = x;
			y2 = y;
			c2 = c;
		} else {
			x1 = x;
			y1 = y;
		}
	}
	int x = (x1 + x2) / 2;
	int y = (y1 + y2) / 2;
	query(x, y);
	if (x1 != x2) {
		if (y == 1)
			y++;
		else
			y--;
	} else {
		if (x == 1)
			x++;
		else
			x--;
	}
	query(x, y);
	cout << "done" << endl;
}

int main() {
	startTime = clock();
//	freopen("input.txt", "r", stdin);
//	freopen("output.txt", "w", stdout);

	int t;
	cin >> t;
	for (int i = 1; i <= t; i++) {
		eprintf("--- Case #%d start ---\n", i);
		//printf("Case #%d: ", i);

		solve();

		//printf("%lld\n", (ll)solve());

		/*
		if (solve()) {
			printf("Yes\n");
		} else {
			printf("No\n");
		}
		*/

		eprintf("--- Case #%d end ---\n", i);
		eprintf("time = %.5lf\n", getCurrentTime());
		eprintf("++++++++++++++++++++\n");
	}



	return 0;
}
