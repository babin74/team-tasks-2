#include <bits/stdc++.h>

using namespace std;
using pi = pair<int, int>;
using ll = long long;

map<pi, int> cache;
int ask(int x, int y) {
    pi cell{x, y};
    if (!cache.count(cell)) {
        cout << "ask " << x << " " << y << endl;
        cin >> cache[cell];
    }
    return cache[cell];
}

int ask(pi cell) {
    return ask(cell.first, cell.second);
}

void done() {
    cout << "done" << endl;
}

pi Path(pi A, pi B, ll k) {
    const int dx = B.first > A.first ? 1 : -1;
    const int dy = B.second > A.second ? 1 : -1;
    const auto [sx, sy] = A;

    ll x = min<ll>(abs(A.first - B.first), k);
    ll y = k - x;
    return {sx + x * dx, sy + y * dy};
}

void solve() {
    cache.clear();

    int n, m;
    cin >> n >> m;
    array<pi, 3> s;
    for (auto& [x, y] : s)
        cin >> x >> y;
    cache[s[0]] = 1;
    cache[s[1]] = 2;
    cache[s[2]] = 3;

    for (int sx = 0; sx < 3; ++sx) {
        for (int sy = 0; sy < sx; ++sy) {
            const pi A = s[sx];
            const pi B = s[sy];
            const ll dist = abs(A.first - B.first) + abs(A.second - B.second);
            if (dist % 2 == 1)
                continue;
            ll L = 0, R = dist / 2;
            while (L + 1 != R) {
                ll M = (L + R) / 2;
                if (ask(Path(A, B, 2 * L)) != ask(Path(A, B, 2 * M))) {
                    R = M;
                } else {
                    L = M;
                }
            }

            ask(Path(A, B, 2 * L + 1));
            auto [px, py] = Path(A, B, 2 * L);
            auto [mx, my] = Path(A, B, 2 * L + 1);
            auto [qx, qy] = Path(A, B, 2 * R);

            if (px == qx) {
                for (int dx : array<int, 2>{{-1, +1}}) {
                    if (1 <= mx + dx && mx + dx <= n) {
                        ask(mx + dx, my);
                        break;
                    }
                }
            }

            if (py == qy) {
                for (int dy : array<int, 2>{-1, +1}) {
                    if (1 <= my + dy && my + dy <= m) {
                        ask(mx, my + dy);
                        break;
                    }
                }
            }
            done();
            return;
        }
    }
}

int main() {
    int t = 1;
    cin >> t;
    while (t--)
        solve();
}