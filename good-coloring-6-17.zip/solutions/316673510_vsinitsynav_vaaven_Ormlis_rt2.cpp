#include "bits/stdc++.h"
#define rep(i, n) for(int i = 0; i < (n); ++i)
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
#define ar array

using namespace std;
using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;
using pi = pair<int, int>;
using vpi = vector<pi>;
using vvi = vector<vi>;

const int INFi = 2e9;
const ll INF = 2e18;

int Col(ar<int, 3> P) {
    return (P[0] ^ P[1]) & 1;
}

ar<int, 3> ask(ar<int, 2> P) {
    cout << "ask " << P[0] << ' ' << P[1] << endl;
    int x; cin >> x;
    return {P[0], P[1], x};
}

void solve() {
    int n, m;
    cin >> n >> m;
    ar<int, 3> A, B, C;
    rep(i, 2) cin >> A[i];
    rep(i, 2) cin >> B[i];
    rep(i, 2) cin >> C[i];
    A[2] = 1;
    B[2] = 2;
    C[2] = 3;

    if (Col(A) == Col(C)) {
        swap(B, C);
    } else if (Col(A) == Col(C)) {
        swap(A, C);
    }
    assert(Col(A) == Col(B));

    if (A > B) swap(A, B);

    // A[0] <= B[0]

    if (A[0] + 1 < B[0]) {
        int x = A[0];
        int y = B[1];
        if (x % 2 != B[0] % 2) x++;

        C = ask({x, y});

        if (B[2] != C[2]) {
            A = C;
            // equal y
        } else {
            B = C;
            // almost equal x
        }
    }
    assert(A[2] != B[2]);

    auto check = [&] () {
        assert(abs(A[0] - B[0]) == 1 && abs(A[1] - B[1]) == 1);
        ask({A[0], B[1]});
        cout << "done" << endl;
        return;
    };

    if (abs(A[0] - B[0]) == 1 && abs(A[1] - B[1]) == 1) {
        check();
        return;
    }

    rep(i, 2) {
        if (A[i] != B[i]) {
            if (abs(A[i] - B[i]) == 1) {
                if (B[i] + 1 == A[i]) swap(A, B);
                assert(A[i] + 1 == B[i]);
                ar<int, 2> P = {0, 0};
                P[i] = B[i];
                if (A[i^1] < B[i^1]) {
                    P[i^1] = A[i^1]+1;
                } else {
                    P[i^1] = A[i^1]-1;
                }

                C = ask(P);
                if (C[2] != A[2]) {
                    B = C;
                    check();
                    return;
                }
                A = C;
                assert(A[i] == B[i]);
            } else {
                continue;
            }
        }

        if (A[i^1] > B[i^1]) swap(A, B);

        int l = A[i^1];
        int r = B[i^1];

        while (r - l > 2) {
            assert(r % 2 == l % 2);

            int mid = (l + r) / 2;

            ar<int, 2> P;
            P[i] = A[i];
            P[i^1] = mid;

            C = ask(P);

            if (C[2] != A[2]) {
                B = C;
                r = mid;
            } else {
                A = C;
                l = mid;
            }
        }

        if (A[i] > 1) {
            ar<int, 2> P;
            P[i] = A[i] - 1;
            P[i^1] = A[i^1] + 1;
            ask(P);
            P[i] = A[i];
            ask(P);
        } else {
            ar<int, 2> P;
            P[i] = A[i] + 1;
            P[i^1] = A[i^1] + 1;
            ask(P);
            P[i] = A[i];
            ask(P);
        }
        cout << "done" << endl;
        return;
    }

    assert(0);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout << setprecision(10) << fixed;
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
}